module Wirispluginengine
  class Engine < ::Rails::Engine
    isolate_namespace Wirispluginengine
  end
end
