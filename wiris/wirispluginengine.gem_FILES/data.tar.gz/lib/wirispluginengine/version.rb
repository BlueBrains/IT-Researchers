module Wirispluginengine
  VERSION = "3.54.1.1164"
end