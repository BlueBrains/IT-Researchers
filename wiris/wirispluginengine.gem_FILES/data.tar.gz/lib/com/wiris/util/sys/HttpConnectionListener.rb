module HttpConnectionListenerInterface
  def HttpConnectionListener
    return true
  end
end