module StorageAndCacheInterface
  def StorageAndCache
    return true
  end
end