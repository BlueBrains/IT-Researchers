module ConfigurationUpdaterInterface
  def ConfigurationUpdater
    return true
  end
end