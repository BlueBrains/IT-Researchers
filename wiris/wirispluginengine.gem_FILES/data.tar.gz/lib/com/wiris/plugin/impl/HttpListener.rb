module HttpListenerInterface
  def HttpListener
    return true
  end
end