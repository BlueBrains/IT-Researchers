module RenderInterface
  def Render
    return true
  end
end