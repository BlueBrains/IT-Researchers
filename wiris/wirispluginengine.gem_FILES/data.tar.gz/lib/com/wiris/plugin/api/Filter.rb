module FilterInterface
  def Filter
    return true
  end
end