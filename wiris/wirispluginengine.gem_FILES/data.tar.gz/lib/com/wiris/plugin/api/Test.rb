module TestInterface
  def Test
    return true
  end
end