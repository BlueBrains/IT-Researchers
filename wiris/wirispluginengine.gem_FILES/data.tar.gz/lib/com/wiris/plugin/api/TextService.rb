module TextServiceInterface
  def TextService
    return true
  end
end