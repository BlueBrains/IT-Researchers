module CasInterface
  def Cas
    return true
  end
end