module ConfigurationInterface
  def Configuration
    return true
  end
end