module EditorInterface
  def Editor
    return true
  end
end