require "wirispluginengine/engine"
require "loader"

module Wirispluginengine
end
