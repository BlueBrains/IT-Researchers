module Wiris
	class Math
		def self.round(f)
			return f.round
		end

		def self.random()
			return Random::rand()
		end
	end
end