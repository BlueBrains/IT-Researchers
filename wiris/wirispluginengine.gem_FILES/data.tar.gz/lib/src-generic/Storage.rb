class Storage
	TYPE_FILE = 0;
	TYPE_RESOURCE = 1;
	TYPE_URL =2;
	@cls = nil
	@@resourcesDir = nil

	def type=(type)
		@type = type
	end
	def type
		@type
	end
	def file=(file)
		@file = file
	end
	def file
		@file
	end
	def resourceName
		@resourceName
	end
	def resourceName=(resourceName)
		@resourceName = resourceName
	end

	def location
		@location
	end
	private:location

	def self.resourcesDir=(resourcesDir)
		@@resourcesDir = resourcesDir
	end
	def self.resourcesDir
		@@resourcesDir
	end

	def initialize(location)
		@location = location
	end

	def self.newStorage(name) 
		s = Storage.new(name)
		s.type = TYPE_FILE
		return s
	end

	def self.newResourceStorage(name)
		s = Storage.new(File.join(getResourcesDir,name))
		s.type = TYPE_RESOURCE
		return s;
	end

	def read()
		@file = File.open(location)
		return @file.read()
	end

	def exists()
		return File.exists?(location)
	end

	def self.getResourcesDir()
		if @@resourcesDir.nil?
			setResourcesDir()
		end
		return @@resourcesDir
	end

	def self.setResourcesDir()
		@@resourcesDir = File.dirname(__FILE__)
	end
end