module Wiris
	class Math
		def self.round(f)
			return f.round
		end
	end
end