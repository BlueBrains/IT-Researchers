class Type
  
  def self.resolveClass(name)
  	name = name.to_s
  	name = name.split(".").last
    return eval(name)
    rescue Exception => exc
        return nil
  end

  def self.getClass(o)
  	return o.class.name
  end
end