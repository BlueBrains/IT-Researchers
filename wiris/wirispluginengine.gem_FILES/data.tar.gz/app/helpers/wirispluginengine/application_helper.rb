module Wirispluginengine
  module ApplicationHelper
  end
end
